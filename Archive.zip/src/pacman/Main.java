package pacman;

public class Main {

    public static void main(String[] args) {
        // Create a new window and display it on the screen.
        Window window = new Window();
        window.setVisible(true);
    }

}
